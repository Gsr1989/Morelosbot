#!/usr/bin/env bash
apt-get update && apt-get install -y libfreetype6-dev libjpeg-dev zlib1g-dev liblcms2-dev libopenjp2-7-dev tcl-dev tk-dev python3-tk ghostscript gcc
